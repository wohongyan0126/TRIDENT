import os
import glob
import torch
import argparse
from datasets import load_dataset, concatenate_datasets
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
    DataCollatorForLanguageModeling
)
from transformers.trainer_utils import get_last_checkpoint

def train(data_dir, model_id, output_dir, block_size=128, batch_size=4, epochs=10, times=1):
    print(f"初始化训练任务...")
    print(f"目标模型: {model_id}")

    # 1. 加载 Tokenizer
    tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        tokenizer.pad_token_id = tokenizer.eos_token_id

    # 2. 加载数据集
    txt_files = glob.glob(os.path.join(data_dir, "*.txt"))
    if not txt_files:
        raise ValueError(f"错误: 在 {data_dir} 目录下没有找到任何 .txt 文件。")

    print(f"找到 {len(txt_files)} 个 txt 文件，开始加载...")
    raw_dataset = load_dataset("text", data_files=txt_files, split="train")

    # 过滤空行
    raw_dataset = raw_dataset.filter(lambda x: len(x["text"].strip()) > 0)
    
    # 按照 times 参数重复数据集
    if times > 1:
        raw_dataset = concatenate_datasets([raw_dataset] * times)
    
    # 打乱数据集顺序，设定 seed 保证实验可复现
    raw_dataset = raw_dataset.shuffle(seed=42)
    
    print(f"数据集已重复 {times} 次并打乱，当前总有效样本: {len(raw_dataset)} 行。")

    # 3. Tokenize (按行处理，固定长度)
    def tokenize_function(examples):
        return tokenizer(
            examples["text"],
            truncation=True,
            max_length=block_size,
            padding="max_length"
        )

    print("进行 Tokenization...")
    tokenized_dataset = raw_dataset.map(
        tokenize_function,
        batched=True,
        num_proc=os.cpu_count(),
        remove_columns=["text"]
    )

    # 4. 加载模型
    print("加载模型权重...")
    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        trust_remote_code=True,
        torch_dtype=torch.bfloat16,
        device_map="auto"
    )

    # 5. Data Collator
    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False
    )

    # 6. 检测历史断点
    last_checkpoint = None
    if os.path.isdir(output_dir):
        last_checkpoint = get_last_checkpoint(output_dir)
        if last_checkpoint is not None:
            print(f"检测到断点，将从 {last_checkpoint} 恢复训练。")

    # 7. TrainingArguments
    # 7. TrainingArguments
    training_args = TrainingArguments(
        output_dir=output_dir,
        per_device_train_batch_size=batch_size,
        gradient_accumulation_steps=4,
        num_train_epochs=epochs,
        
        # --- 针对“记忆/过拟合”优化的核心参数 ---
        learning_rate=1e-4,          # 提高学习率
        weight_decay=0.0,            # 关闭正则化，鼓励过拟合
        lr_scheduler_type="constant", # 使用恒定学习率
        # ----------------------------------------
        
        bf16=True,

        logging_strategy="steps",
        logging_steps=10,
        logging_first_step=True,
        report_to=["tensorboard"],

        save_strategy="steps",
        save_steps=10000,

        optim="adamw_torch",
        warmup_ratio=0.05,
        gradient_checkpointing=True,
        seed=42,
    )

    # 8. Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_dataset,
        data_collator=data_collator,
    )

    # 9. 执行训练
    print('开始训练...')
    trainer.train(resume_from_checkpoint=last_checkpoint)

    # 10. 保存最终模型
    print('保存最终模型...')
    model.save_pretrained(output_dir, safe_serialization=True)
    tokenizer.save_pretrained(output_dir)

    print(f'训练结束。模型及分词器已保存至: {output_dir}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="模型微调脚本")
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--block_size", type=int, default=128)
    parser.add_argument("--times", type=int, default=2, help="数据集重复的次数")

    args = parser.parse_args()

    model_mapping = {
        "qwen": "Qwen/Qwen2-1.5B",
        "tinyllama": "TinyLlama/TinyLlama-1.1B-intermediate-step-1431k-3T",
        "llama3": "meta-llama/Llama-3.2-1B"
    }
    
    selected_model_id = model_mapping["qwen"]

    train(
        data_dir="/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS_length/Datasets/dataset_128/public",
        model_id=selected_model_id,
        output_dir="/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/Qwen2.5-1.5B/model/public_model",
        batch_size=args.batch_size,
        epochs=args.epochs,
        block_size=args.block_size,
        times=args.times
    )