import os
import json
import zlib
from math import exp
from collections import Counter

import torch
import numpy as np
from scipy.stats import wasserstein_distance

from transformers import GPT2LMHeadModel, GPT2Tokenizer, logging
from rouge_score import rouge_scorer
from bert_score import BERTScorer  # 引入 BERTScorer 对象，替代函数调用
from nltk.translate.bleu_score import sentence_bleu
from nltk.translate.meteor_score import meteor_score
from nltk.tokenize import word_tokenize

from utils import get_samples_list

logging.set_verbosity_error()  # 设置日志级别为 error，仅显示错误信息 

# ==========================================
# 优化点 1: 全局初始化 Scorer，避免每次循环重复加载模型和正则器
# ==========================================
ROUGE_SCORER = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
BERT_SCORER = None  # 将在 main 中初始化并挂载到设备

def calculate_rouge(candidate, reference):
    """计算 ROUGE-N 分数"""
    # 直接使用全局实例
    return ROUGE_SCORER.score(candidate, reference)['rouge1'].fmeasure

def calculate_ttr(text):
    """计算文本的类型-标记比率（TTR）"""
    unique_tokens = set(text)
    return len(unique_tokens) / len(text) if len(text) > 0 else 0

def calculate_ngram_stats(text, n):
    """计算文本的 n-gram 的 Distinct 和 Unique 指标"""
    ngrams = [tuple(text[i:i + n]) for i in range(len(text) - n + 1)]
    ngram_counts = Counter(ngrams)
    
    total_ngrams = len(ngrams)
    unique_ngrams = len(ngram_counts)
    distinct = unique_ngrams / total_ngrams if total_ngrams > 0 else 0
    
    return {f"distinct_{n}": distinct, f"unique_{n}": unique_ngrams}

def calculate_bleu(candidate_tokens, reference_tokens):
    """计算 BLEU 分数"""
    return sentence_bleu([reference_tokens], candidate_tokens)

def calculate_meteor(candidate, reference_tokens):
    """计算 METEOR 分数"""
    candidate_tokens = word_tokenize(candidate)  
    # 优化点 2: 提取 reference 的分词到外部，直接传入 token 列表
    return meteor_score([reference_tokens], candidate_tokens)

def compress_and_calculate_length(text):
    """使用 zlib 压缩文本并计算压缩后的长度"""
    compressed = zlib.compress(text.encode('utf-8'))
    return len(compressed)

def calculate_bertscore(candidate, reference):
    """计算 BERTScore"""
    # 直接调用全局模型进行计算，省略重复加载的开销
    P, R, F1 = BERT_SCORER.score([candidate], [reference])
    return F1.mean().item()

def calculate_perplexity(text, model, tokenizer):
    """计算 Perplexity"""
    input_ids = tokenizer(text, return_tensors="pt").input_ids.to(model.device)
    # 外部已经加上了 inference_mode，此处无需额外 no_grad
    outputs = model(input_ids, labels=input_ids)
    loss = outputs.loss.item()
    return exp(loss)

# 优化点 3: 加上 inference_mode，替代并超越 no_grad 的效果，极大提升速度
@torch.inference_mode()
def sampling_based_distribution(target_text, model, tokenizer, n_samples=1, zlib_flag=0, prefix_ratio=0.2):
    """
    计算基于采样的分布
    """
    words = target_text.split()
    prefix_length = max(1, int(len(words) * prefix_ratio))
    x_prefix = ' '.join(words[:prefix_length])
    x_ref = ' '.join(words[prefix_length:])

    # 模型支持的最大长度
    max_model_length = model.config.n_positions
    target_gen_length = len(x_ref.split())

    # 优化点 4: 将 Tokenizer 处理移出生成循环，避免重复计算
    input_ids = tokenizer(x_prefix, return_tensors='pt').input_ids.to(model.device)
    input_length = input_ids.shape[1]
    max_gen_length = min(max_model_length - input_length, target_gen_length)

    candidate_texts = []
    for _ in range(n_samples):
        # 注意：如果此处没有开启 do_sample=True 且 n_samples > 1，生成内容将完全一致。
        # 为了保证输出结果与你的原代码完全一样，这里保持原逻辑不变。
        outputs = model.generate(
            input_ids, 
            max_length=input_length + max_gen_length,
            num_beams=5,
            early_stopping=True
        )  
        generated_tokens = outputs[0][input_length:]
        candidate_text = tokenizer.decode(generated_tokens, skip_special_tokens=True)
        candidate_texts.append(candidate_text)

    # 优化点 5: 提取公共变量，避免重复转换
    full_reference = target_text
    ref_words = full_reference.split()
    ref_tokens_nltk = word_tokenize(full_reference) # 为 METEOR 提前分词

    scores = []
    for candidate in candidate_texts:
        # 备注：保持你原代码中的 candidate + x_prefix (前缀加在生成词后面) 逻辑，确保输出分数不变
        full_candidate =  x_prefix + candidate
        candidate_words = full_candidate.split()
        
        ttr = calculate_ttr(candidate_words)
        distinct_1 = calculate_ngram_stats(candidate_words, 1)
        distinct_2 = calculate_ngram_stats(candidate_words, 2)
        bleu = calculate_bleu(candidate_words, ref_words)
        meteor = calculate_meteor(full_candidate, ref_tokens_nltk)
        rouge_scores = calculate_rouge(full_candidate, full_reference)
        bert_score = calculate_bertscore(full_candidate, full_reference)
        perplexity = calculate_perplexity(full_candidate, model, tokenizer)

        scores.append({
            'rouge': rouge_scores,
            'bert_score': bert_score,
            'perplexity': perplexity,
            'ttr': ttr,
            'bleu': bleu,
            'meteor': meteor,
            'distinct_1': distinct_1,
            'distinct_2': distinct_2
        })

    return scores

def calculate_distribution_difference(reference_scores, vanilla_scores):
    """计算两个分布的差异"""
    return wasserstein_distance(reference_scores, vanilla_scores)

def run_samia_and_compute_differences(tokenizer, models, n_samples=5, zlib_flag=1):
    """
    运行 SaMIA 并计算分布差异
    """
    samples_dir_path = f'/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS_length/Datasets/dataset_128/public'
    output_dir = f'/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt/gpt-774/output/public'
    os.makedirs(output_dir, exist_ok=True)

    print(f'Processing data from {samples_dir_path}')
    file_list = os.listdir(samples_dir_path)
    all_books_results = []

    for file in file_list:
        data = get_samples_list(os.path.join(samples_dir_path, file))
        book_name = file.split('.')[0]
        
        book_results = {
            "book_name": book_name,
            "samples": []
        }

        for i, sample in enumerate(data):
            baseline_scores = sampling_based_distribution(sample, models['public_model'], tokenizer, n_samples, zlib_flag, prefix_ratio=0.1)
            baseline_tune_scores = sampling_based_distribution(sample, models['copyright_model'], tokenizer, n_samples, zlib_flag, prefix_ratio=0.1)
    
            sample_data = {
                "sample_index": i + 1,
                "baseline_scores": baseline_scores,
                "baseline_tune_scores": baseline_tune_scores,
            }
            
            book_results["samples"].append(sample_data)
            
            sample_output_path = os.path.join(output_dir, f"{book_name}_sample_{i+1}_results.json")
            with open(sample_output_path, 'w', encoding='utf-8') as f:
                json.dump(sample_data, f, indent=4, ensure_ascii=False)

            print(f"Saved results for {book_name} sample {i+1}")
        
        book_output_path = os.path.join(output_dir, f"{book_name}_results.json")
        with open(book_output_path, 'w', encoding='utf-8') as f:
            json.dump(book_results, f, indent=4, ensure_ascii=False)

        print(f"Saved results for book: {book_name}")
        all_books_results.append(book_results)

    all_differences_path = os.path.join(output_dir, 'all_books_differences.json')
    with open(all_differences_path, 'w', encoding='utf-8') as f:
        json.dump(all_books_results, f, indent=4, ensure_ascii=False)

    print(f"All books differences saved to {all_differences_path}")


if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # 提前初始化全局的 BERTScorer，将其固定在对应 GPU/CPU 上
    print('Initializing BERTScorer...')
    BERT_SCORER = BERTScorer(lang="en", rescale_with_baseline=False, device=device)

    model_dirs = {
        'public_model': '/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt/gpt-774/gpt2_774m_pub',
        'copyright_model':'/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt/gpt-774/gpt2_774m_copy'
    }

    print('Loading models...')
    models = {}
    for key, path in model_dirs.items():
        # 如果你想进一步将显存占用减半且接受极微小（千分之一量级）的指标误差，
        # 请取消下面 torch_dtype=torch.float16 的注释：
        models[key] = GPT2LMHeadModel.from_pretrained(
            path, 
            # torch_dtype=torch.float16 
        ).to(device)
        
    tokenizer = GPT2Tokenizer.from_pretrained(model_dirs['public_model'])
    print('<<< Models loaded successfully >>>')

    run_samia_and_compute_differences(
        tokenizer=tokenizer,
        models=models,
        n_samples=1,
        zlib_flag=0
    )

'''import os
import json
import zlib
import time  # 新增：引入时间模块
from math import exp
from collections import Counter

import torch
import numpy as np
from scipy.stats import wasserstein_distance
from tqdm import tqdm  # 确保进度条可见

from transformers import GPT2LMHeadModel, GPT2Tokenizer, logging
from rouge_score import rouge_scorer
from bert_score import BERTScorer  # 引入 BERTScorer 对象，替代函数调用
from nltk.translate.bleu_score import sentence_bleu
from nltk.translate.meteor_score import meteor_score
from nltk.tokenize import word_tokenize

from utils import get_samples_list

logging.set_verbosity_error()  # 设置日志级别为 error，仅显示错误信息 

# ==========================================
# 全局初始化 Scorer
# ==========================================
ROUGE_SCORER = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
BERT_SCORER = None  # 将在 main 中初始化并挂载到设备

def calculate_rouge(candidate, reference):
    return ROUGE_SCORER.score(candidate, reference)['rouge1'].fmeasure

def calculate_ttr(text):
    unique_tokens = set(text)
    return len(unique_tokens) / len(text) if len(text) > 0 else 0

def calculate_ngram_stats(text, n):
    ngrams = [tuple(text[i:i + n]) for i in range(len(text) - n + 1)]
    ngram_counts = Counter(ngrams)
    total_ngrams = len(ngrams)
    unique_ngrams = len(ngram_counts)
    distinct = unique_ngrams / total_ngrams if total_ngrams > 0 else 0
    return {f"distinct_{n}": distinct, f"unique_{n}": unique_ngrams}

def calculate_bleu(candidate_tokens, reference_tokens):
    return sentence_bleu([reference_tokens], candidate_tokens)

def calculate_meteor(candidate, reference_tokens):
    candidate_tokens = word_tokenize(candidate)  
    return meteor_score([reference_tokens], candidate_tokens)

def compress_and_calculate_length(text):
    compressed = zlib.compress(text.encode('utf-8'))
    return len(compressed)

def calculate_bertscore(candidate, reference):
    P, R, F1 = BERT_SCORER.score([candidate], [reference])
    return F1.mean().item()

def calculate_perplexity(text, model, tokenizer):
    input_ids = tokenizer(text, return_tensors="pt").input_ids.to(model.device)
    outputs = model(input_ids, labels=input_ids)
    loss = outputs.loss.item()
    return exp(loss)

@torch.inference_mode()
def sampling_based_distribution(target_text, model, tokenizer, n_samples=1, zlib_flag=0, prefix_ratio=0.2):
    words = target_text.split()
    prefix_length = max(1, int(len(words) * prefix_ratio))
    x_prefix = ' '.join(words[:prefix_length])
    x_ref = ' '.join(words[prefix_length:])

    max_model_length = model.config.n_positions
    target_gen_length = len(x_ref.split())

    input_ids = tokenizer(x_prefix, return_tensors='pt').input_ids.to(model.device)
    input_length = input_ids.shape[1]
    max_gen_length = min(max_model_length - input_length, target_gen_length)

    candidate_texts = []
    for _ in range(n_samples):
        outputs = model.generate(
            input_ids, 
            max_length=input_length + max_gen_length,
            num_beams=5,
            early_stopping=True
        )  
        generated_tokens = outputs[0][input_length:]
        candidate_text = tokenizer.decode(generated_tokens, skip_special_tokens=True)
        candidate_texts.append(candidate_text)

    full_reference = target_text
    ref_words = full_reference.split()
    ref_tokens_nltk = word_tokenize(full_reference)

    scores = []
    for candidate in candidate_texts:
        full_candidate =  x_prefix + candidate
        candidate_words = full_candidate.split()
        
        ttr = calculate_ttr(candidate_words)
        distinct_1 = calculate_ngram_stats(candidate_words, 1)
        distinct_2 = calculate_ngram_stats(candidate_words, 2)
        bleu = calculate_bleu(candidate_words, ref_words)
        meteor = calculate_meteor(full_candidate, ref_tokens_nltk)
        rouge_scores = calculate_rouge(full_candidate, full_reference)
        bert_score = calculate_bertscore(full_candidate, full_reference)
        perplexity = calculate_perplexity(full_candidate, model, tokenizer)

        scores.append({
            'rouge': rouge_scores,
            'bert_score': bert_score,
            'perplexity': perplexity,
            'ttr': ttr,
            'bleu': bleu,
            'meteor': meteor,
            'distinct_1': distinct_1,
            'distinct_2': distinct_2
        })

    return scores

def calculate_distribution_difference(reference_scores, vanilla_scores):
    return wasserstein_distance(reference_scores, vanilla_scores)

def run_samia_and_compute_differences(tokenizer, models, n_samples=5, zlib_flag=1):
    samples_dir_path = f'/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS_length/Datasets/dataset_128/copyright/seen'
    output_dir = f'/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt/gpt-774/output/seen'
    os.makedirs(output_dir, exist_ok=True)

    # ================= 记录数据加载时间 =================
    print("⏳ 正在加载并截断数据集...")
    t0_data = time.time()
    file_list = os.listdir(samples_dir_path)
    
    # 扁平化收集所有样本，以便统一截断
    all_tasks = []
    for file in file_list:
        data = get_samples_list(os.path.join(samples_dir_path, file))
        book_name = file.split('.')[0]
        for i, sample in enumerate(data):
            all_tasks.append({
                "book_name": book_name,
                "sample_index": i + 1,
                "sample_text": sample
            })

    # 强制截取前 2000 个样本
    if len(all_tasks) > 2000:
        all_tasks = all_tasks[:2000]
    elif len(all_tasks) < 2000:
        print(f"⚠️ 警告: 数据集样本量不足 2000，当前只有 {len(all_tasks)} 个样本！")
        
    data_load_time = time.time() - t0_data
    print(f"✅ 数据加载完成 (共 {len(all_tasks)} 条)，耗时: {data_load_time:.2f} 秒")

    # ================= 记录特征提取与模型推理时间 =================
    print(f"🚀 开始对 {len(all_tasks)} 个样本进行特征提取与推理...")
    t0_inference = time.time()
    
    # 用于按书名重新聚合结果保存
    all_books_results_dict = {}

    for task in tqdm(all_tasks, desc="Evaluating"):
        book_name = task["book_name"]
        sample_idx = task["sample_index"]
        sample = task["sample_text"]

        if book_name not in all_books_results_dict:
            all_books_results_dict[book_name] = {"book_name": book_name, "samples": []}

        # 分别调用两个模型获取指标特征
        baseline_scores = sampling_based_distribution(sample, models['public_model'], tokenizer, n_samples, zlib_flag, prefix_ratio=0.1)
        baseline_tune_scores = sampling_based_distribution(sample, models['copyright_model'], tokenizer, n_samples, zlib_flag, prefix_ratio=0.1)

        sample_data = {
            "sample_index": sample_idx,
            "baseline_scores": baseline_scores,
            "baseline_tune_scores": baseline_tune_scores,
        }
        
        all_books_results_dict[book_name]["samples"].append(sample_data)
        
        # 保存单样本 JSON
        sample_output_path = os.path.join(output_dir, f"{book_name}_sample_{sample_idx}_results.json")
        with open(sample_output_path, 'w', encoding='utf-8') as f:
            json.dump(sample_data, f, indent=4, ensure_ascii=False)

    # 汇总并保存全书 JSON
    all_books_results = []
    for book_name, book_results in all_books_results_dict.items():
        book_output_path = os.path.join(output_dir, f"{book_name}_results.json")
        with open(book_output_path, 'w', encoding='utf-8') as f:
            json.dump(book_results, f, indent=4, ensure_ascii=False)
        all_books_results.append(book_results)

    all_differences_path = os.path.join(output_dir, 'all_books_differences.json')
    with open(all_differences_path, 'w', encoding='utf-8') as f:
        json.dump(all_books_results, f, indent=4, ensure_ascii=False)

    inference_time = time.time() - t0_inference
    return data_load_time, inference_time


if __name__ == '__main__':
    # ================= 记录全局开始时间 =================
    global_start_time = time.time()
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    print('⏳ 正在加载 BERTScorer...')
    t0_bert = time.time()
    BERT_SCORER = BERTScorer(lang="en", rescale_with_baseline=False, device=device)
    bert_load_time = time.time() - t0_bert
    
    model_dirs = {
        'public_model': '/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt/gpt-774/gpt2_774m_pub',
        'copyright_model':'/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt/gpt-774/gpt2_774m_copy'
    }

    print('⏳ 正在加载 GPT 模型...')
    t0_models = time.time()
    models = {}
    for key, path in model_dirs.items():
        models[key] = GPT2LMHeadModel.from_pretrained(path).to(device)
        
    tokenizer = GPT2Tokenizer.from_pretrained(model_dirs['public_model'])
    models_load_time = time.time() - t0_models
    print('✅ 模型加载完成')

    data_load_time, inference_time = run_samia_and_compute_differences(
        tokenizer=tokenizer,
        models=models,
        n_samples=1,
        zlib_flag=0
    )
    
    total_time = time.time() - global_start_time

    # ================= 打印最终时间报告 =================
    print("\n" + "="*45)
    print("📊 样本处理时间报告 (Tri-Eval 特征提取 - 2000样本)")
    print("="*45)
    print(f"BERTScorer 加载耗时:   {bert_load_time:.2f} 秒")
    print(f"GPT2 模型加载耗时:     {models_load_time:.2f} 秒")
    print(f"数据加载与处理耗时:    {data_load_time:.2f} 秒")
    print("-" * 45)
    print(f"核心推理提取特征耗时:  {inference_time:.2f} 秒 (填入表格的 ? 值)")
    print("-" * 45)
    print(f"脚本运行总耗时:        {total_time:.2f} 秒")
    print("="*45)'''