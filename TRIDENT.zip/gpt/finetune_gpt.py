# finetune.py 
import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer, Trainer, TrainingArguments
import os, argparse, configparser
from trainset_builder import build_GPT2_trainset
from transformers import LlamaForCausalLM, LlamaTokenizer, Trainer, TrainingArguments
from torch import distributed as dist
from transformers import BitsAndBytesConfig
'''os.environ['HTTP_PROXY'] = 'http://127.0.0.1:7890'
os.environ['HTTPS_PROXY'] = 'http://127.0.0.1:7890'
export HF_ENDPOINT="https://hf-mirror.com"
os.environ['HUGGING_FACE_HUB_TOKEN'] = "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"'''
#export HUGGING_FACE_HUB_TOKEN="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"
#export CUDA_VISIBLE_DEVICES=5,l
#torchrun --nproc_per_node=2 --master_port=29500 finetune.py
#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
from torch.utils.data.distributed import DistributedSampler
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.distributed import init_process_group, destroy_process_group
from transformers.trainer_utils import get_last_checkpoint
import os
#CUDA_VISIBLE_DEVICES=3 python /3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt/all_scores_gpt.py

def train(source_data_path, model_name, output_dir, block_size, times,
         per_device_train_batch_size, num_train_epochs, save_steps):
     # 添加分布式初始化
    '''device=ddp_setup()
    local_rank = int(os.environ["LOCAL_RANK"])'''
    # 初始化分词器
    tokenizer = GPT2Tokenizer.from_pretrained(model_name)
    # 获取当前设备
    #tokenizer = LlamaTokenizer.from_pretrained(model_name)

    tokenizer.pad_token = tokenizer.eos_token
    
    train_dataset, data_collator = build_GPT2_trainset(
        source_data_path=source_data_path,
        tokenizer=tokenizer,
        block_size=block_size,
        times=times
    )
 
    print('load base model from ' + model_name)
    # 加载模型并调整embeddings
    model = GPT2LMHeadModel.from_pretrained(model_name)
    
    training_args = TrainingArguments(
        output_dir=output_dir,
        dataloader_num_workers=2,
        
        per_device_train_batch_size=per_device_train_batch_size,
        num_train_epochs=num_train_epochs,
        save_steps=save_steps,
        fp16=True,  # 启用混合精度
        logging_steps=50,
        gradient_checkpointing=True,
        gradient_accumulation_steps=16
        #dataloader_drop_last=True

    )
    print(f"Dataset size: {len(train_dataset)}")
    '''for i in range(5):
        print(train_dataset[i])  # 打印前 5 条数据
    print(len(train_dataset))'''

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        data_collator=data_collator,
        #sampler=train_sampler
    )
    '''print('load base model finish!!!')
    tokenizer.save_pretrained(output_dir)
    trainer.train()
    print('model save to ' + output_dir)
    model.save_pretrained(output_dir)'''
    #destroy_process_group()
    print('load base model finish!!!')
    tokenizer.save_pretrained(output_dir)

    # 2. 自动检测最新的 checkpoint
    last_checkpoint = None
    if os.path.isdir(output_dir):
        last_checkpoint = get_last_checkpoint(output_dir)

    # 3. 判断并执行训练
    if last_checkpoint is not None:
        print(f"检测到历史断点，正在从 {last_checkpoint} 恢复训练...")
        trainer.train(resume_from_checkpoint=last_checkpoint)
    else:
        print("未检测到历史断点，开始全新的训练...")
        trainer.train()

    print('model save to ' + output_dir)
    model.save_pretrained(output_dir)

if __name__ == '__main__':
    # 配置解析优化
    config = configparser.ConfigParser()
    config.read("/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt/config")
    
    parser = argparse.ArgumentParser()
    parser.add_argument("-mt", "--model_type", default="baseline-tune", 
                       choices=['reference', 'baseline-tune'])
    args = parser.parse_args()

    train(
        source_data_path='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS_length/Datasets/dataset_128/copyright+public',
        model_name='gpt2-large',
        output_dir='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt/gpt-774/gpt2_774m_copy',
        block_size=int(config.get("environment", "block_size")),
        times=int(config.get("environment", "times")),

        per_device_train_batch_size=int(config.get("environment", "per_device_train_batch_size")),
        num_train_epochs=int(config.get("environment", "num_train_epochs")),
        save_steps=int(config.get("environment", "save_steps"))
    )

'''model_name='gpt2'
model_name='gpt2-medium'
model_name='gpt2-large'
model_name='gpt2-xl'
'''
'''
模型	参数量
gpt2	124M
gpt2-medium	355M
gpt2-large	774M
gpt2-xl	1.5B
'''
