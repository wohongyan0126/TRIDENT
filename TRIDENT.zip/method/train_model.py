import os
import json
import time
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import auc, classification_report, roc_curve

# ------------------------------
# Data Loading Module (复用原有方法)
# ------------------------------
def load_data(folder_path, label=None):
    """加载JSON格式测试数据，支持标签分配"""
    data = []
    for filename in os.listdir(folder_path):
        if filename.endswith('.json'):
            filepath = os.path.join(folder_path, filename)
            try:
                with open(filepath, 'r') as f:
                    content = json.load(f)
                    baseline = content['baseline_scores'][0]
                    tune = content['baseline_tune_scores'][0]
                    
                    row = {
                        'sample_id': content['sample_index'],
                        # 基准指标
                        'rouge_base': baseline['rouge'],
                        'bert_score_base': baseline['bert_score'],
                        'perplexity_base': baseline['perplexity'],
                        'ttr_base': baseline['ttr'],
                        'bleu_base': baseline['bleu'],
                        'meteor_base': baseline['meteor'],
                        'distinct_1_base': baseline['distinct_1']['distinct_1'],
                        # 微调指标
                        'rouge_tune': tune['rouge'],
                        'bert_score_tune': tune['bert_score'],
                        'perplexity_tune': tune['perplexity'],
                        'ttr_tune': tune['ttr'],
                        'bleu_tune': tune['bleu'],
                        'meteor_tune': tune['meteor'],
                        'distinct_1_tune': tune['distinct_1']['distinct_1'],
                    }
                    if label is not None:  # 添加标签支持
                        row['label'] = label
                    data.append(row)
            except Exception as e:
                print(f"警告：跳过{filename}，错误 - {str(e)}")
    return pd.DataFrame(data)

# ------------------------------
# 模型训练模块
# ------------------------------
def train_classifier_model(positive_dir, negative_dir, output_dir):
    """训练分类模型"""
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. 加载数据
    print("🔄 加载训练数据...")
    df_pos = load_data(positive_dir)
    df_neg = load_data(negative_dir)
    
    # 添加标签
    df_pos['label'] = 1  # 正样本标签
    df_neg['label'] = 0  # 负样本标签
    
    # 合并数据集
    df = pd.concat([df_pos, df_neg], axis=0)
    
    # 2. 特征工程
    print("🔧 特征处理...")
    # 提取所有指标特征 (排除非特征列)
    feature_cols = [col for col in df.columns 
                   if col.endswith('_base') or col.endswith('_tune')]
    X = df[feature_cols]
    y = df['label']
    
    # 3. 数据预处理
    print("📊 标准化数据...")
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # 4. 划分训练测试集
    print("✂️ 划分数据集...")
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, 
        test_size=0.2, 
        stratify=y,
        random_state=42
    )
    
    # 5. 训练模型
    print("🤖 训练随机森林分类器...")
    model = RandomForestClassifier(
        n_estimators=150,
        max_depth=8,
        class_weight='balanced',
        random_state=42
    )
    model.fit(X_train, y_train)
    
    # 6. 模型评估
    print("📈 模型评估:")
    y_pred = model.predict(X_test)
    print(classification_report(y_test, y_pred))
    
    # 7. 保存资源
    print("💾 保存模型和参数...")
    # 保存模型
    joblib.dump(model, os.path.join(output_dir, 'copyright_model.pkl'))
    # 保存标准化器
    joblib.dump(scaler, os.path.join(output_dir, 'copyright_scaler.pkl'))
    # 保存特征列
    with open(os.path.join(output_dir, 'feature_columns.txt'), 'w') as f:
        f.write('\n'.join(feature_cols))
    
    print(f"✅ 训练完成！模型已保存至: {output_dir}")

# ------------------------------
# 测试推理模块
# ------------------------------
def predict_copyright(model_dir, pos_test_dir, neg_test_dir):
    """使用训练好的模型进行预测和评估"""
    t0_total = time.time()  # 记录测试总开始时间
    
    # 1. 加载资源
    print("🔍 加载模型资源...")
    model = joblib.load(os.path.join(model_dir, 'copyright_model.pkl'))
    scaler = joblib.load(os.path.join(model_dir, 'copyright_scaler.pkl'))
    with open(os.path.join(model_dir, 'feature_columns.txt'), 'r') as f:
        feature_cols = [line.strip() for line in f]

    # 2. 加载并合并测试数据
    print("📂 加载测试数据...")
    t0_load = time.time()
    df_pos = load_data(pos_test_dir, label=1)  # 正样本标签为1
    df_neg = load_data(neg_test_dir, label=0)  # 负样本标签为0
    df_test = pd.concat([df_pos, df_neg], axis=0)
    data_load_time = time.time() - t0_load
    print(f"✅ 测试数据加载完成，耗时: {data_load_time:.2f} 秒")
    
    # 3. 特征处理
    print("⚙️ 处理特征...")
    missing_cols = set(feature_cols) - set(df_test.columns)
    if missing_cols:
        raise ValueError(f"测试数据缺少必要特征: {missing_cols}")
    X_test = df_test[feature_cols]
    y_true = df_test['label']

    # 4. 标准化
    X_test_scaled = scaler.transform(X_test)

    # 5. 预测
    print("🔮 执行预测...")
    t0_infer = time.time()
    y_probs = model.predict_proba(X_test_scaled)[:, 1]
    y_pred = model.predict(X_test_scaled)
    inference_time = time.time() - t0_infer
    print(f"✅ 推理完成，耗时: {inference_time:.2f} 秒")

    # 6. 计算评估指标
    print("📊 计算评估指标...")
    # ROC曲线数据
    fpr, tpr, thresholds = roc_curve(y_true, y_probs)
    roc_auc = auc(fpr, tpr)
    
    # FPR@95%TPR
    tpr_95_idx = np.where(tpr >= 0.95)[0]
    fpr_95 = fpr[tpr_95_idx[0]] if tpr_95_idx.size > 0 else 1.0
    
    # TPR@5%FPR
    fpr_5_idx = np.where(fpr <= 0.05)[0]
    tpr_05 = tpr[fpr_5_idx[-1]] if fpr_5_idx.size > 0 else 0.0

    test_total_time = time.time() - t0_total

    # 7. 保存结果
    print("💾 保存结果...")
    # 预测结果
    df_result = df_test[['sample_id']].copy()
    df_result['prediction'] = y_pred
    df_result['probability'] = y_probs
    df_result['status'] = df_result['prediction'].map({1: 'Copyrighted', 0: 'Clean'})
    
    # 评估指标 (新增时间开销记录)
    metrics_df = pd.DataFrame({
        'Metric': [
            'AUC', 'FPR@95%TPR', 'TPR@5%FPR', 
            'Data_Load_Time(s)', 'Inference_Time(s)', 'Total_Test_Time(s)'
        ],
        'Value': [
            roc_auc, fpr_95, tpr_05, 
            data_load_time, inference_time, test_total_time
        ]
    })
    
    # ROC曲线数据
    roc_df = pd.DataFrame({
        'FPR': fpr,
        'TPR': tpr,
        'Thresholds': thresholds
    })

    # 保存路径
    save_dir = os.path.join(model_dir, 'test_results')
    os.makedirs(save_dir, exist_ok=True)
    
    df_result.to_csv(os.path.join(save_dir, 'predictions.csv'), index=False)
    metrics_df.to_csv(os.path.join(save_dir, 'evaluation_metrics.csv'), index=False)
    roc_df.to_csv(os.path.join(save_dir, 'roc_curve_data.csv'), index=False)

    # 8. 打印结果
    print("\n=== 评估结果 ===")
    print(metrics_df.to_string(index=False))
    print(f"\nROC曲线数据已保存至：{save_dir}")
    print(f"🎉 整个测试流程完毕，总耗时: {test_total_time:.2f} 秒")

    return df_result

# ------------------------------
# 主程序
# ------------------------------
if __name__ == "__main__":
    # ===== 训练模式 =====
    '''train_config = {
        "positive_dir": "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/model_method/qwen/train_pos",
        "negative_dir": "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/model_method/qwen/train_neg",
        "output_dir": "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/model_method/model_output_qwen"
    }
    train_classifier_model(**train_config)'''
    
    # ===== 测试模式 =====
    test_config = {
        "model_dir": "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/model_method/model_output_qwen",
        "pos_test_dir": "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/model_method/qwen/test_pos_1000",
        "neg_test_dir": "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/model_method/qwen/test_neg_1000"
    }
    results = predict_copyright(**test_config)
    results.to_csv(os.path.join(test_config['model_dir'], 'predictions_postive.csv'), index=False)