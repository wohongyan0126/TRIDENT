import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.metrics import auc, roc_curve
from sklearn.preprocessing import StandardScaler
from scipy import stats
from joblib import Parallel, delayed
from matplotlib.patches import Patch
from matplotlib import colors as mcolors, patheffects
from matplotlib.patches import Wedge, Patch  # 新增导入
import matplotlib.patches as mpatches        # 或使用此方式导入

# ------------------------------
# 数据加载模块
# ------------------------------
def load_data(folder_path):
    """加载JSON格式的测试结果"""
    data = []
    for filename in os.listdir(folder_path):
        if filename.endswith('.json'):
            filepath = os.path.join(folder_path, filename)
            try:
                with open(filepath, 'r') as f:
                    content = json.load(f)
                    baseline = content['baseline_scores'][0]
                    tune = content['baseline_tune_scores'][0]
                    
                    row = {
                        'sample_id': content['sample_index'],
                        # 基准模型指标
                        'rouge_base': baseline['rouge'],
                        'bert_score_base': baseline['bert_score'],
                        'perplexity_base': baseline['perplexity'],
                        'ttr_base': baseline['ttr'],
                        'bleu_base': baseline['bleu'],
                        'meteor_base': baseline['meteor'],
                        'distinct_1_base': baseline['distinct_1']['distinct_1'],
                        # 微调模型指标
                        'rouge_tune': tune['rouge'],
                        'bert_score_tune': tune['bert_score'],
                        'perplexity_tune': tune['perplexity'],
                        'ttr_tune': tune['ttr'],
                        'bleu_tune': tune['bleu'],
                        'meteor_tune': tune['meteor'],
                        'distinct_1_tune': tune['distinct_1']['distinct_1'],
                    }
                    data.append(row)
            except Exception as e:
                print(f"警告：跳过{filename}，错误 - {str(e)}")
    return pd.DataFrame(data)

# ------------------------------
# 核心处理模块
# ------------------------------
class CopyrightDetector:
    def __init__(self, metric_config):
        """
        :param metric_config: 指标分类配置
        example: {
            "structure": ['rouge', 'bleu'],
            "diversity": ['ttr', 'distinct_1'],
            "semantic": ['bert_score','meteor', 'perplexity']
        }
        """
        self.metric_config = metric_config
        self.scaler = None
        self.weights = None
        
    def _hierarchical_pca(self, X_base):
        """分层PCA权重计算"""
        # 第一层：类内权重
        category_weights = {}
        metric_weights = {}
        
        # 标准化处理
        X_std = self.scaler.transform(X_base)
        
        # 类内PCA
        for category, metrics in self.metric_config.items():
            cols = [f"{m}_base" for m in metrics]
            indices = [X_base.columns.get_loc(c) for c in cols]
            
            if len(metrics) == 1:
                category_weights[category] = 1.0
                metric_weights[metrics[0]] = 1.0
                continue
                
            pca = PCA(n_components=1)
            pca.fit(X_std[:, indices])
            loadings = np.abs(pca.components_[0])
            norm_weights = loadings / loadings.sum()
            
            category_weights[category] = pca.explained_variance_ratio_[0]
            for m, w in zip(metrics, norm_weights):
                metric_weights[m] = w
                
        # 第二层：类间PCA
        category_features = []
        for category in self.metric_config.keys():
            cols = [f"{m}_base" for m in self.metric_config[category]]
            indices = [X_base.columns.get_loc(c) for c in cols]
            
            if len(cols) > 1:
                pca = PCA(n_components=1).fit(X_std[:, indices])
                feature = pca.transform(X_std[:, indices])
            else:
                feature = X_std[:, indices]
                
            category_features.append(feature)
            
        X_top = np.hstack(category_features)
        top_pca = PCA(n_components=1).fit(X_top)
        top_weights = np.abs(top_pca.components_[0])
        top_weights_norm = top_weights / top_weights.sum()
        
        # 合成最终权重
        final_weights = np.zeros(X_std.shape[1])
        for i, category in enumerate(self.metric_config.keys()):
            cat_weight = top_weights_norm[i]
            for metric in self.metric_config[category]:
                col = f"{metric}_base"
                idx = X_base.columns.get_loc(col)
                final_weights[idx] = metric_weights[metric] * cat_weight
                
        return final_weights / final_weights.sum()
    
    def fit(self, df_pos, df_neg, df_con):
        """训练检测器"""
        # 合并基准数据
        base_cols = [f"{m}_base" for category in self.metric_config.values() for m in category]
        X_base = pd.concat([df_pos[base_cols], df_neg[base_cols], df_con[base_cols]])
        
        # 标准化
        self.scaler = StandardScaler().fit(X_base)
        
        # 计算权重
        self.weights = self._hierarchical_pca(X_base)
        self.base_columns_ = [f"{m}_base" for category in self.metric_config.values() for m in category]
        return self

    
    def _calculate_score(self, df, suffix):
        """计算综合得分"""
        cols = [f"{m}_{suffix}" for category in self.metric_config.values() for m in category]
        X = df[cols].values
        return np.dot(self.scaler.transform(X), self.weights)
    
    def transform(self, df):
        """生成综合得分"""
        df = df.copy()
        df['score_base'] = self._calculate_score(df, 'base')
        df['score_tune'] = self._calculate_score(df, 'tune')
        df['did_raw'] = df['score_tune'] - df['score_base']
        return df

    def adjusted_did(self, df, control_mean):
        """计算DID（不减去控制组均值，保留变量名为did_adjusted保证输出一致）"""
        df = df.copy()
        # 修改点：直接使用 did_raw，不减去 control_mean
        df['did_adjusted'] = df['did_raw'] 
        return df

    def bootstrap_null(self, df_neg, df_con, n_iter=5000):
        """构建零分布（使用负样本和对照组数据）"""
        # 合并负样本和对照组数据
        combined_scores = pd.concat([
            df_neg[['score_base', 'score_tune']],
            df_con[['score_base', 'score_tune']]
        ]).values
        
        def _single_bootstrap():
            # 双重重采样（从合并数据中）
            idx1 = np.random.choice(len(combined_scores), size=500, replace=True)
            idx2 = np.random.choice(len(combined_scores), size=500, replace=True)
            delta1 = (combined_scores[idx1,1] - combined_scores[idx1,0]).mean()
            delta2 = (combined_scores[idx2,1] - combined_scores[idx2,0]).mean()
            
            # 计算原始DID
            raw_did = delta1 - delta2
            
            # 修改点：直接返回 raw_did
            return raw_did 
        
        null_dist = Parallel(n_jobs=8)(delayed(_single_bootstrap)() for _ in range(n_iter))
        return np.array(null_dist)

    def save_artifacts(self, output_dir):
        """保存所有训练中间结果"""
        os.makedirs(output_dir, exist_ok=True)
        
        with open(os.path.join(output_dir, 'scaler_params.txt'), 'w') as f:
            f.write("# Metric\tMean\tStd\n")
            for i, col in enumerate(self.base_columns_):
                f.write(f"{col.replace('_base', '')}\t{self.scaler.mean_[i]:.6f}\t{self.scaler.scale_[i]:.6f}\n")
        # 2. 保存特征权重
        weight_data = []
        for idx, col in enumerate(self.base_columns_):
            metric = col.replace('_base', '')
            category = next(cat for cat, metrics in self.metric_config.items() if metric in metrics)
            weight_data.append({
                'category': category,
                'metric': metric,
                'weight': self.weights[idx]
            })
        pd.DataFrame(weight_data).to_csv(os.path.join(output_dir, 'feature_weights.csv'), index=False)
        with open(os.path.join(output_dir, 'feature_weights.txt'), 'w') as f:
            f.write("# Metric\tWeight\n")
            for idx, col in enumerate(self.base_columns_):
                metric = col.replace('_base', '')
                f.write(f"{metric}\t{self.weights[idx]:.4f}\n")

        # 3. 保存指标配置
        with open(os.path.join(output_dir, 'metric_config.json'), 'w') as f:
            json.dump(self.metric_config, f, indent=2)

# ------------------------------
# 可视化模块
# ------------------------------
class Visualizer:
    
    @staticmethod
    def plot_threshold(null_dist, threshold, output_dir):
        """阈值可视化"""
        plt.figure(figsize=(8,6))
        sns.histplot(null_dist, bins=50, kde=True, color='steelblue')
        plt.axvline(threshold, color='r', linestyle='--', label=f'99% Threshold ({threshold:.2f})')
        plt.xlabel("Null DID Values")
        plt.ylabel("Density")
        plt.title("Null Distribution")
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'threshold_analysis.png'), dpi=300)
        plt.close()
    
    @staticmethod
    def plot_did_comparison(null_dist, pos_did, neg_did, threshold, output_dir):
        """DID对比可视化"""
        plt.figure(figsize=(10,6))
        sns.kdeplot(null_dist, label='Null Distribution', fill=True, color='grey')
        sns.kdeplot(pos_did, label='Positive Samples', fill=True, color='red', alpha=0.5)
        sns.kdeplot(neg_did, label='Negative Samples', fill=True, color='blue', alpha=0.5)
        plt.axvline(threshold, color='black', linestyle='--', label=f'99% Threshold')
        
        plt.title("DID Distribution Comparison")
        plt.xlabel("DID Value")
        plt.ylabel("Density")
        plt.legend()
        plt.savefig(os.path.join(output_dir, 'did_comparison.png'), dpi=300)
        plt.close()

    def plot_weight_pie(weight_df, output_dir):
        """绘制权重扇形图"""
        plt.figure(figsize=(12, 8))
        category_weights = weight_df.groupby('category')['weight'].sum()
        colors = sns.color_palette('pastel', len(category_weights))
        patches, texts, autotexts = plt.pie(
            category_weights,
            labels=category_weights.index,
            colors=colors,
            autopct='%1.1f%%',
            startangle=140,
            pctdistance=0.85,
            wedgeprops={'linewidth': 1.5, 'edgecolor': 'white'}
        )
        plt.title("Feature Weights by Category", fontsize=16, pad=20)
        plt.setp(autotexts, size=12, weight="bold", color="black")
        plt.setp(texts, size=12)
        plt.savefig(os.path.join(output_dir, 'weight_pie.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def plot_detailed_weights(weight_df, output_dir):
        """详细权重分布图"""
        plt.figure(figsize=(15, 8))
        category_palette = {
            "structure": "#FF9999",
            "diversity": "#99CC99",
            "semantic": "#9999FF"
        }
        metric_colors = []
        for _, row in weight_df.iterrows():
            base_color = category_palette[row['category']]
            rgb = mcolors.hex2color(base_color)
            adjusted = [c * (0.6 + 0.4*row['weight']/weight_df['weight'].max()) for c in rgb]
            metric_colors.append(mcolors.rgb2hex(adjusted))
        
        ax = sns.barplot(x='metric', y='weight', data=weight_df, palette=metric_colors)
        for p in ax.patches:
            ax.annotate(f"{p.get_height():.3f}", 
                        (p.get_x() + p.get_width() / 2., p.get_height()),
                        ha='center', va='center', 
                        xytext=(0, 9), 
                        textcoords='offset points')
        
        plt.title("Detailed Feature Weights Distribution", fontsize=16)
        plt.xlabel("Evaluation Metrics", fontsize=12)
        plt.ylabel("Weight Value", fontsize=12)
        plt.xticks(rotation=45)
        plt.legend(title='Category', bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.savefig(os.path.join(output_dir, 'detailed_weights.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def plot_sunburst(weight_df,output_dir):
        """绘制旭日图展示层次结构"""
        data = []
        for _, row in weight_df.iterrows():
            data.append({
                'id': row['metric'],
                'parent': row['category'],
                'value': row['weight']
            })
            data.append({
                'id': row['category'],
                'parent': 'Total',
                'value': None
            })
        
        import plotly.express as px
        fig = px.sunburst(
            data,
            names='id',
            parents='parent',
            values='value',
            color='id',
            color_continuous_scale='RdBu'
        )
        fig.update_layout(margin=dict(t=0, l=0, r=0, b=0))
        fig.write_image(os.path.join(output_dir, 'sunburst.png'))

    def plot_weight_distribution(weight_df, output_dir):
        """复合权重扇形图"""
        plt.figure(figsize=(12, 12))
        category_colors = sns.color_palette('pastel', n_colors=len(weight_df['category'].unique()))
        metric_colors = sns.color_palette('husl', n_colors=len(weight_df))
        ax = plt.subplot(111)
        
        category_weights = weight_df.groupby('category')['weight'].sum()
        outer_labels = [f"{k}\n({v:.1%})" for k,v in category_weights.items()]
        wedges_outer, texts_outer = ax.pie(
            category_weights,
            radius=1.2,
            colors=category_colors,
            startangle=140,
            wedgeprops=dict(width=0.4, edgecolor='w', linewidth=2),
            labels=outer_labels,
            labeldistance=0.85,
            textprops=dict(rotation_mode='anchor', va='center', ha='center', fontsize=12)
        )
        
        inner_labels = [f"{row['metric']}\n{row['weight']:.1%}" 
                       if row['weight'] > 0.05 else '' 
                       for _, row in weight_df.iterrows()]
        wedges_inner, texts_inner = ax.pie(
            weight_df['weight'],
            radius=0.8,
            colors=metric_colors,
            startangle=140,
            wedgeprops=dict(edgecolor='w', linewidth=1),
            labels=inner_labels,
            rotatelabels=True,
            textprops=dict(rotation_mode='anchor', 
                          va='center', 
                          ha='center',
                          fontsize=10,
                          bbox=dict(boxstyle="round,pad=0.2", 
                                  fc="white", 
                                  ec="none", 
                                  alpha=0.8))
        )
        
        plt.text(0, 0, "Weight\nDistribution", 
                ha='center', va='center', 
                fontsize=16, fontweight='bold')
        
        legend_elements = []
        for cat, color in zip(category_weights.index, category_colors):
            legend_elements.append(Patch(facecolor=color, 
                                       label=f"{cat} ({category_weights[cat]:.1%})"))
        plt.legend(handles=legend_elements, 
                 loc='upper left',
                 bbox_to_anchor=(1.05, 1),
                 title="Categories")
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'combined_weight_chart.png'), 
                  dpi=300, 
                  bbox_inches='tight')
        plt.close()

    def calculate_best_threshold(df_all, output_dir):
        """
        计算基于ROC曲线的最佳阈值（Youden指数）
        """
        y_true = np.where(df_all['sample_type'] == 'Positive', 1, 0)
        y_score = df_all['did_adjusted'].values
        
        fpr, tpr, thresholds = roc_curve(y_true, y_score)
        roc_auc = auc(fpr, tpr)
        
        youden_idx = np.argmax(tpr - fpr)
        best_threshold = thresholds[youden_idx]
        
        plt.figure(figsize=(10, 8))
        plt.plot(fpr, tpr, color='darkorange', lw=2, 
                label=f'ROC curve (AUC = {roc_auc:.4f})')
        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
        plt.plot(fpr[youden_idx], tpr[youden_idx], 'ro', markersize=8)
        plt.annotate(f'Optimal Threshold: {best_threshold:.4f}\n(TPR={tpr[youden_idx]:.2f}, FPR={fpr[youden_idx]:.2f})',
                    xy=(fpr[youden_idx], tpr[youden_idx]),
                    xytext=(fpr[youden_idx] + 0.1, tpr[youden_idx] - 0.1),
                    arrowprops=dict(facecolor='black', arrowstyle='->'))
        
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Receiver Operating Characteristic (ROC) Curve', fontsize=16)
        plt.legend(loc="lower right")
        plt.grid(alpha=0.3)
        
        plt.savefig(os.path.join(output_dir, 'roc_curve.png'), dpi=300, bbox_inches='tight')
        plt.close()
        
        return best_threshold, roc_auc

# ------------------------------
# 主流程
# ------------------------------
def main(positive_dir, negative_dir, control_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    
    print("🔄 加载数据...")
    df_pos = load_data(positive_dir)  # 参与微调的版权数据
    df_neg = load_data(negative_dir)  # 未参与微调的版权数据
    df_con = load_data(control_dir)   # 公开数据（参与过两个模型微调）
    
    metric_config = {
        "structure": ['rouge', 'bleu'],
        "diversity": ['ttr', 'distinct_1'],
        "semantic": ['bert_score','meteor', 'perplexity']
    }
    df_pos['sample_type'] = 'Positive'
    df_neg['sample_type'] = 'Negative'
    df_con['sample_type'] = 'Control'
    
    detector = CopyrightDetector(metric_config).fit(df_pos, df_neg, df_con)
    
    print("🧮 计算综合得分...")
    df_pos = detector.transform(df_pos)
    df_neg = detector.transform(df_neg)
    df_con = detector.transform(df_con)
    control_mean = df_con['did_raw'].mean()
  
    df_pos = detector.adjusted_did(df_pos, control_mean)
    df_neg = detector.adjusted_did(df_neg, control_mean)
    df_con = detector.adjusted_did(df_con, control_mean)

    print("📊 计算最佳阈值...")
    viz_dir = os.path.join(output_dir, 'visualizations')
    os.makedirs(viz_dir, exist_ok=True)
    df_all = pd.concat([df_pos, df_neg, df_con])
    
    best_threshold, roc_auc = Visualizer.calculate_best_threshold(df_all, viz_dir)
    
    print("💾 保存中间参数...")
    artifacts_dir = os.path.join(output_dir, 'training_artifacts')
    detector.save_artifacts(artifacts_dir)
    
    print("🎨 生成权重可视化...")
    weight_df = pd.read_csv(os.path.join(artifacts_dir, 'feature_weights.csv'))
    Visualizer.plot_weight_pie(weight_df, output_dir)
    Visualizer.plot_detailed_weights(weight_df, output_dir)
    Visualizer.plot_weight_distribution(weight_df, output_dir)
    
    print("📝 生成检测报告...")
    report = {
        "threshold": float(best_threshold),
        "positive_mean_did": float(df_pos['did_adjusted'].mean()),
        "negative_mean_did": float(df_neg['did_adjusted'].mean()),
        "control_mean_did": float(df_con['did_adjusted'].mean()),
    }
    with open(os.path.join(output_dir, 'report.json'), 'w') as f:
        json.dump(report, f, indent=2)
    with open(os.path.join(artifacts_dir, 'threshold_params.txt'), 'w') as f:
        f.write("# Threshold Parameters\n")
        f.write(f"Combined Threshold (99th percentile): {best_threshold:.6f}\n")
        f.write(f"Control Group Baseline: {df_con['did_raw'].mean():.6f}\n")
        f.write(f"Positive Samples Count: {len(df_pos)}\n")
        f.write(f"Negative Samples Count: {len(df_neg)}\n")
        f.write(f"Control Samples Count: {len(df_con)}\n")
        
    print(f"✅ 分析完成！结果保存在：{output_dir}")

if __name__ == "__main__":
    config = {
        "positive_dir": "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/weight_method/data_threshold/GPT-Neo_1.3B+GPT-Neo_1.3B/seen",
        "negative_dir": "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/weight_method/data_threshold/GPT-Neo_1.3B+GPT-Neo_1.3B/unseen",
        "control_dir": "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/weight_method/data_threshold/GPT-Neo_1.3B+GPT-Neo_1.3B/public",
        "output_dir": "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/weight_method/output_threshold/GPT-Neo_1.3B+GPT-Neo_1.3B-DID/"
    }
    main(**config)