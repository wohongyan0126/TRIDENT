import os
import json
import argparse
import time
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    roc_curve,
    auc
)
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm

# ------------------------------
# 参数加载模块
# ------------------------------
def save_results(metrics, report_df, params, result_dir):
    """保存所有结果文件"""
    # 创建保存目录
    os.makedirs(result_dir, exist_ok=True)
    fpr, tpr, _ = roc_curve(report_df["true_label"], report_df["pred_score"])
    pd.DataFrame({'FPR': fpr, 'TPR': tpr}).to_csv(
        os.path.join(result_dir, "composite_roc_data.csv"), 
        index=False
    )
    # 保存详细预测结果
    detail_path = os.path.join(result_dir, "detailed_predictions")
    report_df.to_csv(f"{detail_path}.csv", index=False)
    report_df.to_excel(f"{detail_path}.xlsx", index=False)
    
    # 保存评估指标报告
    with open(os.path.join(result_dir, "evaluation_report.txt"), "w") as f:
        # 新增：记录时间开销
        f.write("=== 时间开销 ===\n")
        if 'process_time' in metrics:
            f.write(f"样本处理耗时: {metrics['process_time']:.2f} 秒\n")
            f.write(f"总运行耗时: {metrics['total_time']:.2f} 秒\n\n")

        f.write("=== 评估指标报告 ===\n")
        f.write(f"准确率 (Accuracy): {metrics['accuracy']:.4f}\n")
        f.write(f"精确率 (Precision): {metrics['precision']:.4f}\n")
        f.write(f"召回率 (Recall): {metrics['recall']:.4f}\n")
        f.write(f"F1值 (F1-Score): {metrics['f1']:.4f}\n")
        f.write(f"特异度 (Specificity): {metrics['specificity']:.4f}\n")
        f.write(f"假阴性率 (FNR): {metrics['fnr']:.4f}\n")
        f.write(f"假阳性率 (FPR): {metrics['fpr']:.4f}\n")
        f.write(f"AUC值: {metrics['auc']:.4f}\n")
        f.write(f"FPR@95%TPR: {metrics['fpr95']:.4f}\n")
        f.write(f"TPR@5%FPR: {metrics['tpr05']:.4f}\n\n")
        
        f.write("=== 混淆矩阵 ===\n")
        cm = metrics["confusion_matrix"]
        f.write(f"| {'TP':<4} | {'FP':<4} |\n")
        f.write(f"| {cm['TP']:<4} | {cm['FP']:<4} |\n")
        f.write(f"| {'FN':<4} | {'TN':<4} |\n")
        f.write(f"| {cm['FN']:<4} | {cm['TN']:<4} |\n")
    
    # 保存可视化图表
    plt.figure(figsize=(12, 5))
    
    # ROC曲线
    plt.subplot(1, 2, 1)
    fpr, tpr, _ = roc_curve(report_df["true_label"], report_df["pred_score"])
    plt.plot(fpr, tpr, label=f'AUC = {metrics["auc"]:.2f}')
    plt.plot([0, 1], [0, 1], linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve')
    plt.legend()
    
    # 混淆矩阵热力图
    plt.subplot(1, 2, 2)
    # 修正后的正确结构
    cm_matrix = [
        [cm['TP'], cm['FN']],  # 第一行：实际正类 (TP, FN)
        [cm['FP'], cm['TN']]   # 第二行：实际负类 (FP, TN)
    ]
    sns.heatmap(cm_matrix, annot=True, fmt='d', cmap='Blues')
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.title('Confusion Matrix')
    
    plt.tight_layout()
    plt.savefig(os.path.join(result_dir, "visualization.png"))
    plt.close()
    
    # 保存原始参数备份
    with open(os.path.join(result_dir, "params_backup.json"), "w") as f:
        json.dump(params, f, indent=2)

def load_training_params(output_dir):
    """加载训练生成的参数文件"""
    params = {}
    
    try:
        # 加载特征权重
        weights_path = os.path.join(output_dir, "feature_weights.txt")
        weights = {}
        with open(weights_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("#") or line.strip() == "":
                    continue
                parts = line.strip().split("\t")
                if len(parts) >= 2:
                    metric = parts[0].strip()
                    weight = float(parts[1].strip())
                    weights[metric] = weight
        params["weights"] = weights
        
        # 加载标准化参数
        scaler_path = os.path.join(output_dir, "scaler_params.txt")
        scaler_mean = {}
        scaler_std = {}
        with open(scaler_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("#") or line.strip() == "":
                    continue
                parts = line.strip().split("\t")
                if len(parts) >= 3:
                    metric = parts[0].strip()
                    scaler_mean[metric] = float(parts[1].strip())
                    scaler_std[metric] = float(parts[2].strip())
        params["scaler_mean"] = scaler_mean
        params["scaler_std"] = scaler_std
        
        # 加载阈值参数
        threshold_path = os.path.join(output_dir, "threshold_params.txt")
        with open(threshold_path, "r", encoding="utf-8") as f:
            for line in f:
                if "Combined Threshold" in line:
                    params["threshold"] = float(line.split(": ")[1].strip())
                if "Control Group Baseline" in line:
                    params["control_baseline"] = float(line.split(": ")[1].strip())
                    
    except Exception as e:
        raise RuntimeError(f"参数加载失败: {str(e)}")
    
    return params

# ------------------------------
# 得分计算模块
# ------------------------------
def calculate_composite_score(metrics_dict, params, score_type):
    """计算复合得分"""
    composite_score = 0.0
    for metric, weight in params["weights"].items():
        # 获取原始指标值
        raw_value = metrics_dict.get(f"{metric}_{score_type}", 0.0)
        
        # 标准化处理
        mean = params["scaler_mean"].get(metric, 0.0)
        std = params["scaler_std"].get(metric, 1.0)
        standardized = (raw_value - mean) / std if std != 0 else 0.0
        
        # 加权累加
        composite_score += standardized * weight
        
    return composite_score

# ------------------------------
# 文件处理模块（新增预测分数返回）
# ------------------------------
def process_single_file(filepath, params, true_label):
    """处理单个测试文件"""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
            
            # 提取基准和调优指标
            baseline = data["baseline_scores"][0]
            tune = data["baseline_tune_scores"][0]
            
            # 构建指标字典
            metrics = {
                # 基准指标
                "rouge_base": baseline["rouge"],
                "bert_score_base": baseline["bert_score"],
                "perplexity_base": baseline["perplexity"],
                "ttr_base": baseline["ttr"],
                "bleu_base": baseline["bleu"],
                "meteor_base": baseline["meteor"],
                "distinct_1_base": baseline["distinct_1"]["distinct_1"],
                "unique_1_base": baseline["distinct_1"]["unique_1"],
                
                # 调优指标
                "rouge_tune": tune["rouge"],
                "bert_score_tune": tune["bert_score"],
                "perplexity_tune": tune["perplexity"],
                "ttr_tune": tune["ttr"],
                "bleu_tune": tune["bleu"],
                "meteor_tune": tune["meteor"],
                "distinct_1_tune": tune["distinct_1"]["distinct_1"],
                "unique_1_tune": tune["distinct_1"]["unique_1"],
            }
            
            # 计算得分
            score_base = calculate_composite_score(metrics, params, "base")
            score_tune = calculate_composite_score(metrics, params, "tune")
            
            # 计算DID指标
            raw_did = score_tune - score_base
            adj_did = raw_did - params["control_baseline"]
            
            # 侵权判定
            threshold = params["threshold"]
            is_infringement = adj_did > threshold
            
            return {
                "file_name": os.path.basename(filepath),
                "file_path": filepath,
                "true_label": true_label,
                "pred_score": adj_did,  # 预测分数
                "prediction": 1 if is_infringement else 0,
                "confidence": abs(adj_did - threshold),
            }
            
    except Exception as e:
        print(f"处理文件失败 {filepath}: {str(e)}")
        return None

def sample_files(directory, sample_size, label_type):
    """
    从指定目录随机抽样文件
    :param directory: 目录路径
    :param sample_size: 需要抽取的数量
    :param label_type: 样本类型描述（用于日志）
    :return: 选中的文件路径列表
    """
    if not os.path.exists(directory):
        raise FileNotFoundError(f"{label_type}目录不存在：{directory}")
    
    all_files = [
        os.path.join(directory, f) 
        for f in os.listdir(directory) 
        if f.endswith(".json")
    ]
    
    if not all_files:
        raise ValueError(f"{label_type}目录中没有JSON文件：{directory}")
    
    # 实际抽样数量控制
    actual_size = min(sample_size, len(all_files))
    if actual_size < sample_size:
        print(f"警告：{label_type}目录只有 {len(all_files)} 个文件，将抽取全部")
    
    selected = np.random.choice(all_files, size=actual_size, replace=False)
    return selected.tolist()

# ------------------------------
# 增强评估模块
# ------------------------------
def generate_evaluation_report(results):
    """生成包含完整指标的评估报告"""
    df = pd.DataFrame(results)
    
    if df.empty:
        return {"error": "无有效数据"}, df
    
    # 基础分类指标
    y_true = df["true_label"]
    y_pred = df["prediction"]
    y_score = df["pred_score"]
    
    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "specificity": recall_score(y_true, y_pred, pos_label=0, zero_division=0)
    }
    
    # ROC曲线指标
    try:
        fpr, tpr, _ = roc_curve(y_true, y_score)
        metrics["auc"] = auc(fpr, tpr)
        metrics["fpr95"] = fpr[np.argmax(tpr >= 0.95)] if np.any(tpr >= 0.95) else 1.0
        metrics["tpr05"] = tpr[np.argmax(fpr >= 0.05)] if np.any(fpr >= 0.05) else 0.0
    except ValueError:
        metrics.update({
            "auc": 0.5,
            "fpr95": 1.0,
            "tpr05": 0.0
        })
    
    # 混淆矩阵
    cm = confusion_matrix(y_true, y_pred)
    try:
        tp, fn, fp, tn = cm.ravel()  # 注意顺序变化
    except ValueError:
        tn, fp, fn, tp = 0, 0, 0, 0
    
    metrics["confusion_matrix"] = {
        "TP": tp,
        "FP": fp,
        "TN": tn,
        "FN": fn
    }
    denom_pos = int(tp) + int(fn)
    denom_neg = int(fp) + int(tn)
    metrics["fnr"] = (float(fn) / denom_pos) if denom_pos > 0 else 0.0
    metrics["fpr"] = (float(fp) / denom_neg) if denom_neg > 0 else 0.0

    return metrics, df

# ------------------------------
# 主程序
# ------------------------------
def main():
    parser = argparse.ArgumentParser(description="增强版版权检测评估系统")
    parser.add_argument("--train_dir", default='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/weight_method/output_threshold/gpt-neo_128_0.1', help="训练输出目录路径")
    parser.add_argument("--pos_dir", default='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/cross_validation/gpt-neo_128_0.1/seen', help="正样本数据目录")
    parser.add_argument("--neg_dir1", default='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/cross_validation/gpt-neo_128_0.1/unseen', help="负样本数据目录1")
    parser.add_argument("--neg_dir2", default='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/cross_validation/gpt-neo_128_0.1/public', help="负样本数据目录2")
    parser.add_argument("--result_dir", default='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/weight_method/output_eval/0407_gpt-neo_128_0.1', help="结果保存目录")
    parser.add_argument("--neg_samples1", type=int, default=500, 
                      help="从目录1抽取的负样本数（默认500）")
    parser.add_argument("--neg_samples2", type=int, default=500,
                      help="从目录2抽取的负样本数（默认500）")
    parser.add_argument("--pos_samples", type=int, default=1000, 
                      help="正样本抽取数量（默认1000）")
    parser.add_argument(
        "--threshold",
        type=float,
        default="0.7363",
        help="覆盖 threshold_params.txt 中的 Combined Threshold；用于四组 DID 固定门限消融",
    )


    args = parser.parse_args()
    
    # ================= 记录全局开始时间 =================
    global_start_time = time.time()
    
    try:
        # 初始化目录
        os.makedirs(args.result_dir, exist_ok=True)
        
        # 加载训练参数
        print("🔧 正在加载训练参数...")
        t0_load = time.time()
        params = load_training_params(args.train_dir)
        if args.threshold is not None:
            params["threshold"] = float(args.threshold)
            print(f"📌 使用命令行覆盖阈值 (DID/减 pub 尺度): {params['threshold']:.6f}")
        print(f"✅ 参数加载完成，耗时: {time.time() - t0_load:.2f} 秒")

        # 处理正负样本
        print("\n📂 正在处理样本数据...")
        t0_sample = time.time()
        
        # 抽样正样本
        pos_files = sample_files(
            args.pos_dir, 
            args.pos_samples,
            "正样本"
        )
        
        # 抽样负样本
        neg1_files = sample_files(
            args.neg_dir1,
            args.neg_samples1,
            "负样本目录1"
        )
        neg2_files = sample_files(
            args.neg_dir2,
            args.neg_samples2,
            "负样本目录2"
        )
        
        # 合并所有样本
        all_files = []
        all_files.extend([(f, 1) for f in pos_files])  # 正样本标签为1
        all_files.extend([(f, 0) for f in neg1_files])  # 负样本标签为0
        all_files.extend([(f, 0) for f in neg2_files])

        print(f"✅ 抽样完成！耗时: {time.time() - t0_sample:.2f} 秒。共获得样本：{len(all_files)} 个")
        print(f"  正样本: {len(pos_files)}/{args.pos_samples}")
        print(f"  负样本1: {len(neg1_files)}/{args.neg_samples1}")
        print(f"  负样本2: {len(neg2_files)}/{args.neg_samples2}")
        
        # ============== 处理样本 ==============
        print("\n🔨 正在处理样本...")
        t0_process = time.time()
        results = []
        for file_path, true_label in tqdm(all_files, desc="处理进度"):
            result = process_single_file(file_path, params, true_label)
            if result:
                results.append(result)
        process_time = time.time() - t0_process
        print(f"✅ 样本处理完成，耗时: {process_time:.2f} 秒")
        
        # 生成评估报告
        print("\n📊 正在生成评估报告...")
        t0_report = time.time()
        metrics, report_df = generate_evaluation_report(results)
        
        # 记录整体时间和处理时间到 metrics 字典中，方便在 save_results 中写入 txt
        total_time = time.time() - global_start_time
        metrics['process_time'] = process_time
        metrics['total_time'] = total_time
        
        # 保存结果
        report_path = os.path.join(args.result_dir, "evaluation_report.xlsx")
        report_df.to_excel(report_path, index=False)
        print(f"💾 结果已保存至：{report_path}")
        print("💾 正在保存完整结果...")
        try:
            save_results(metrics, report_df, params, args.result_dir)
            print(f"✅ 所有结果已保存至：{args.result_dir} (保存耗时: {time.time() - t0_report:.2f} 秒)")
        except Exception as e:
            print(f"⚠️ 结果保存出现警告: {str(e)}")
            
        # 打印指标
        print("\n=== 评估结果 ===")
        if "error" in metrics:
            print(f"错误: {metrics['error']}")
        else:
            print(f"准确率 (Accuracy): {metrics['accuracy']:.4f}")
            print(f"精确率 (Precision): {metrics['precision']:.4f}")
            print(f"召回率 (Recall): {metrics['recall']:.4f}")
            print(f"F1值 (F1-Score): {metrics['f1']:.4f}")
            print(f"特异度 (Specificity): {metrics['specificity']:.4f}")
            print(f"假阴性率 (FNR): {metrics['fnr']:.4f}")
            print(f"假阳性率 (FPR): {metrics['fpr']:.4f}")
            print(f"AUC值: {metrics['auc']:.4f}")
            print(f"FPR@95%TPR: {metrics['fpr95']:.4f}")
            print(f"TPR@5%FPR: {metrics['tpr05']:.4f}")
            
            cm = metrics["confusion_matrix"]
            print("\n混淆矩阵:")
            print(f"| {'TP':<4} | {'FP':<4} |")
            print(f"| {cm['TP']:<4} | {cm['FP']:<4} |")
            print(f"| {'FN':<4} | {'TN':<4} |")
            print(f"| {cm['FN']:<4} | {cm['TN']:<4} |")
            
        print(f"\n🎉 整个脚本运行完毕，总耗时: {total_time:.2f} 秒")
        
    except Exception as e:
        import traceback
        print("\n" + "="*40)
        traceback.print_exc()  # 打印完整的报错红字堆栈
        print("="*40)
        print(f"❌ 程序执行失败: {str(e)}")

if __name__ == "__main__":
    main()