import os
import torch
import json
from transformers import AutoModelForCausalLM, AutoTokenizer, logging
from rouge_score import rouge_scorer
import zlib
import numpy as np
from scipy.stats import wasserstein_distance
from bert_score import BERTScorer # ✨ 引入底层类，避免重复加载模型
from math import exp
from collections import Counter
from nltk.translate.bleu_score import sentence_bleu
from nltk.translate.meteor_score import meteor_score
from nltk.tokenize import word_tokenize

logging.set_verbosity_error()  # 设置日志级别为 error，仅显示错误信息 

# ✨ 全局实例化评估器，避免在循环中重复加载模型和正则引擎，提速数十倍到上百倍
GLOBAL_ROUGE_SCORER = None
GLOBAL_BERT_SCORER = None

def init_scorers():
    global GLOBAL_ROUGE_SCORER, GLOBAL_BERT_SCORER
    print("Initializing global metrics scorers...")
    if GLOBAL_ROUGE_SCORER is None:
        GLOBAL_ROUGE_SCORER = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
    if GLOBAL_BERT_SCORER is None:
        GLOBAL_BERT_SCORER = BERTScorer(lang="en", rescale_with_baseline=False)

def calculate_rouge(candidate, reference):
    """
    计算 ROUGE-N 分数 (✨ 优化：使用全局实例)
    """
    scores = GLOBAL_ROUGE_SCORER.score(candidate, reference)
    return scores['rouge1'].fmeasure  # 返回 ROUGE-1 的 F-Measure 分数

def calculate_ttr(text):
    """
    计算文本的类型-标记比率（TTR）
    """
    unique_tokens = set(text)
    return len(unique_tokens) / len(text) if len(text) > 0 else 0

def calculate_ngram_stats(text, n):
    """
    计算文本的 n-gram 的 Distinct 和 Unique 指标
    """
    ngrams = [tuple(text[i:i + n]) for i in range(len(text) - n + 1)]
    ngram_counts = Counter(ngrams)
    
    total_ngrams = len(ngrams)
    unique_ngrams = len(ngram_counts)
    distinct = unique_ngrams / total_ngrams if total_ngrams > 0 else 0
    
    return {
        f"distinct_{n}": distinct,
        f"unique_{n}": unique_ngrams
    }

def calculate_bleu(candidate_tokens, reference_tokens):
    """
    计算 BLEU 分数
    """
    return sentence_bleu([reference_tokens], candidate_tokens)

def calculate_meteor(candidate, reference_tokens):
    """
    计算 METEOR 分数 (✨ 优化：参考文本分词提前到循环外，此处直接传入列表)
    """
    candidate_tokens = word_tokenize(candidate)  # 分词
    return meteor_score([reference_tokens], candidate_tokens)

def compress_and_calculate_length(text):
    """
    使用 zlib 压缩文本并计算压缩后的长度
    """
    compressed = zlib.compress(text.encode('utf-8'))
    return len(compressed)

def calculate_bertscore(candidate, reference):
    """
    计算 BERTScore (✨ 优化：使用全局缓存的预训练模型)
    """
    P, R, F1 = GLOBAL_BERT_SCORER.score([candidate], [reference])
    return F1.mean().item()  # 返回 F1 分数

@torch.inference_mode() # ✨ 优化：使用 inference_mode 替代 no_grad，更彻底关闭计算图，节约显存和时间
def calculate_perplexity(text, model, tokenizer):
    """
    计算 Perplexity
    """
    input_ids = tokenizer(text, return_tensors="pt").input_ids.to(model.device)
    outputs = model(input_ids, labels=input_ids)
    loss = outputs.loss.item()
    return exp(loss)

@torch.inference_mode() # ✨ 优化：使用 inference_mode 替代 no_grad
def sampling_based_distribution(target_text, model, tokenizer, n_samples=1, prefix_ratio=0.2):
    """✨ 改进的采样函数，适配长文本生成"""
    max_ctx = model.config.max_position_embeddings
    inputs = tokenizer(
        target_text, 
        return_tensors="pt", 
        truncation=True, 
        max_length=max_ctx - 50  # 预留50token给生成操作
    )
    clean_text = tokenizer.decode(inputs['input_ids'][0], skip_special_tokens=True)
    
    total_tokens = len(inputs['input_ids'][0])
    safe_prefix_length = min(
        int(total_tokens * prefix_ratio),
        max_ctx - 100  # 确保至少能生成100token
    )
    
    max_new_tokens = max(
        min(
            max_ctx - safe_prefix_length,
            int(total_tokens * (1 - prefix_ratio)) + 50
        ), 
        50  # 设置最低生成长度
    )
    
    generation_config = {
        'max_new_tokens': max_new_tokens,
        'do_sample': True,
        'temperature': 0.1,
        'top_p': 0.9,
        'repetition_penalty': 1.1,
        'no_repeat_ngram_size': 4
    }

    candidate_texts = []
    # 如果可能，这里还可以通过增加 batch_size 来进一步优化，但为了保持原本逻辑结构不变，维持 for 循环
    input_ids = inputs['input_ids'][0][:safe_prefix_length].unsqueeze(0).to(model.device)
    
    for _ in range(n_samples):
        outputs = model.generate(
            input_ids,
            **generation_config,
            pad_token_id=tokenizer.eos_token_id
        )
        
        generated = tokenizer.decode(
            outputs[0][safe_prefix_length:], 
            skip_special_tokens=True,
            clean_up_tokenization_spaces=True
        )
        candidate_texts.append(generated)

    # ✨ 优化：统一将 Reference 的操作移到循环外部，避免对于每个 sample 重复 split 和 tokenization
    full_reference = clean_text
    ref_words = full_reference.split()
    ref_tokens_meteor = word_tokenize(full_reference) # 为 METEOR 提前分词
    decoded_prefix = tokenizer.decode(inputs['input_ids'][0][:safe_prefix_length])

    scores = []
    for candidate in candidate_texts:
        full_candidate = candidate + " " + decoded_prefix
        candidate_words = full_candidate.split()
        
        ttr = calculate_ttr(candidate_words)
        distinct_1 = calculate_ngram_stats(candidate_words, 1)
        distinct_2 = calculate_ngram_stats(candidate_words, 2)
        bleu = calculate_bleu(candidate_words, ref_words)
        meteor = calculate_meteor(full_candidate, ref_tokens_meteor) # 传入提前分好词的ref
        rouge_scores = calculate_rouge(full_candidate, full_reference)
        bert_score = calculate_bertscore(full_candidate, full_reference)
        perplexity = calculate_perplexity(full_candidate, model, tokenizer)

        scores.append({
            'rouge': rouge_scores,
            'bert_score': bert_score,
            'perplexity': perplexity,
            'ttr': ttr,
            'bleu': bleu,
            'meteor': meteor,
            'distinct_1': distinct_1,
            'distinct_2': distinct_2
        })

    return scores


def calculate_distribution_difference(reference_scores, vanilla_scores):
    """
    计算两个分布的差异，使用 Wasserstein 距离
    """
    distance = wasserstein_distance(reference_scores, vanilla_scores)
    return distance

def run_samia_and_compute_differences(tokenizer, models, n_samples=5, zlib_flag=1):
    """
    对数据集运行 SaMIA 并计算分布差异，同时以一本书为单位保存分布和差异到单个文件中
    """
    samples_dir_path = f'/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Datasets/deepseek_dataset/copyright_book/unseen'
    output_dir = f'/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/deepseek/deepseek-1.5B/output/unseen'

    def load_samples(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            separator = "\n\n" 
            chunks = [
                chunk.strip()
                for chunk in content.split(separator)
                if chunk.strip() and chunk.count('<|SECTION_START|>') == 1
            ]
            return chunks

    os.makedirs(output_dir, exist_ok=True)
    print(f'Processing data from {samples_dir_path}')
    file_list = os.listdir(samples_dir_path)
    all_books_results = [] 

    for file in file_list:
        if not file.endswith('.txt'):
            continue
            
        samples = load_samples(os.path.join(samples_dir_path, file))
        book_results = {
            "book_name": file.split('.')[0],
            "samples": []
        }

        for i, sample in enumerate(samples):
            baseline_scores = sampling_based_distribution(sample, models['public_model'], tokenizer, n_samples, prefix_ratio=0.1)
            baseline_tune_scores = sampling_based_distribution(sample, models['copyright_model'], tokenizer, n_samples, prefix_ratio=0.1)
            
            book_results["samples"].append({
                "sample_index": i + 1,
                "baseline_scores": baseline_scores,
                "baseline_tune_scores": baseline_tune_scores,
            })
            sample_result = {
                "sample_index": i + 1,
                "baseline_scores": baseline_scores,
                "baseline_tune_scores": baseline_tune_scores,
            }
            
            sample_output_path = os.path.join(output_dir, f"{file.split('.')[0]}_sample_{i+1}_results.json")
            with open(sample_output_path, 'w', encoding='utf-8') as f:
                json.dump(sample_result, f, indent=4, ensure_ascii=False)

            print(f"Saved results for {file.split('.')[0]} sample {i+1}")
        
        book_output_path = os.path.join(output_dir, f"{file.split('.')[0]}_results.json")
        with open(book_output_path, 'w', encoding='utf-8') as f:
            json.dump(book_results, f, indent=4, ensure_ascii=False)

        print(f"Saved results for book: {file.split('.')[0]}")
        all_books_results.append(book_results)

    all_differences_path = os.path.join(output_dir, 'all_books_differences.json')
    with open(all_differences_path, 'w', encoding='utf-8') as f:
        json.dump(all_books_results, f, indent=4, ensure_ascii=False)

    print(f"All books differences saved to {all_differences_path}")


if __name__ == '__main__':
    # ✨ 必须在开始时初始化全局的打分器引擎
    init_scorers()

    model_dirs = {
        'public_model': '/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/deepseek/deepseek-1.5B/deepseek1.5b_pub',
        'copyright_model':'/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/deepseek/deepseek-1.5B/deepseek1.5b_copyright'
    }

    print('Loading models...')
    models = {
        key: AutoModelForCausalLM.from_pretrained(
            path,
            trust_remote_code=True,
            torch_dtype=torch.bfloat16, 
            device_map="auto" 
        )
        for key, path in model_dirs.items()
    }
    tokenizer = AutoTokenizer.from_pretrained(
        "deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B",
        trust_remote_code=True,
        padding_side="left" 
    )
    tokenizer.pad_token = tokenizer.eos_token
    print('<<< Models loaded successfully >>>')

    run_samia_and_compute_differences(
        tokenizer=tokenizer,
        models=models,
        n_samples=1,
        zlib_flag=0
    )