'''# -*- coding: utf-8 -*- 
# @Time : 2023/8/11 13:46 
# @Author : DirtyBoy 
# @File : trainset_builder.py
import os, torch, random
from transformers import DataCollatorForLanguageModeling
from torch.utils.data import Dataset
from typing import Dict
from utils import txt_to_list

class LineByLineTextDataset(Dataset):
    """适配DeepSeek的数据集类"""

    def __init__(self, tokenizer, file_list, block_size: int):
        print(f"Creating features for DeepSeek")
        
        # DeepSeek需要添加首部空格
        processed_lines = [" " + line.strip() for line in file_list if line.strip()]
        
        # 使用更高效的批量编码
        batch_encoding = tokenizer(
            processed_lines,
            add_special_tokens=True,
            truncation=True,
            max_length=block_size,
            padding="do_not_pad"  # 禁用自动填充
        )
        
        self.examples = []
        for input_ids in batch_encoding["input_ids"]:
            self.examples.append({
                "input_ids": torch.tensor(input_ids, dtype=torch.long),
                "attention_mask": torch.tensor([1]*len(input_ids), dtype=torch.long)
            })

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, i) -> Dict[str, torch.tensor]:
        return self.examples[i]

def build_deepseek_trainset(source_data_path, tokenizer, block_size=2048, times=1):
    novel_list = os.listdir(source_data_path)
    goal_list = []
    for item in novel_list:
        txt_path = os.path.join(source_data_path, item)
        if txt_path.endswith(".txt"):
            txt_list = txt_to_list(txt_path)
            goal_list.extend(txt_list)
    
    # 更好的数据增强策略
    augmented_list = []
    for _ in range(times):
        shuffled = goal_list.copy()
        random.shuffle(shuffled)
        augmented_list.extend(shuffled)
    
    return LineByLineTextDataset(
        tokenizer=tokenizer,
        file_list=augmented_list,
        block_size=block_size,
    ), DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False,
        pad_to_multiple_of=8  # 优化显存使用
    )
'''

# -*- coding: utf-8 -*-
import os
import torch
import random
from transformers import DataCollatorForLanguageModeling
from torch.utils.data import Dataset
from typing import Dict

class DeepSeekChunkDataset(Dataset):
    def __init__(self, tokenizer, file_list, chunk_size=2048):
        self.examples = []
        
        # ✅ 添加文件加载验证
        print(f"正在加载 {len(file_list)} 个数据文件...")
        
        for file_path in file_list:
            if not os.path.isfile(file_path):
                print(f"⚠️ 文件不存在: {file_path}")
                continue
                
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    chunks = [chunk.strip() for chunk in content.split('\n\n') if chunk.strip()]
                    
                    # ✅ 添加分块统计
                    print(f"文件 {os.path.basename(file_path)} 包含 {len(chunks)} 个段落")
                    
                    for chunk in chunks:
                        encoding = tokenizer(
                            chunk,
                            max_length=chunk_size,
                            truncation=True,
                            return_tensors="pt",
                            add_special_tokens=True
                        )
                        if len(encoding['input_ids'][0]) > 0:
                            self.examples.append({
                                'input_ids': encoding['input_ids'][0],
                                'attention_mask': encoding['attention_mask'][0]
                            })
            except Exception as e:
                print(f"⚠️ 加载文件 {file_path} 失败: {str(e)}")

    def __len__(self):
        # ✅ 确保返回整数类型
        return len(self.examples)

    def __getitem__(self, idx):
        return self.examples[idx]


def build_deepseek_trainset(source_data_path, tokenizer, chunk_size=2048, times=1):
    # ✅ 修正文件列表获取方式
    file_list = [
        os.path.join(source_data_path, f)
        for f in os.listdir(source_data_path)
        if f.endswith('.txt') and os.path.isfile(os.path.join(source_data_path, f))
    ]
    
    # ✅ 修正数据增强逻辑
    augmented_files = []
    for _ in range(times):
        shuffled = file_list.copy()
        random.shuffle(shuffled)
        augmented_files.extend(shuffled)
    
    print(f"✅ 共加载 {len(file_list)} 个原始文件 | 增强后 {len(augmented_files)} 个文件")
    return DeepSeekChunkDataset(tokenizer, augmented_files, chunk_size), \
           DataCollatorForLanguageModeling(tokenizer, mlm=False)
