import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
    default_data_collator
)
import os, argparse, configparser
from torch import distributed as dist
from trainset_builder_deepseek import build_deepseek_trainset

def train(source_data_path, model_name, output_dir, block_size=128, times=1,
          overwrite_output_dir=False, per_device_train_batch_size=4,
          num_train_epochs=3, save_steps=500):
    
    # 初始化DeepSeek分词器
    tokenizer = AutoTokenizer.from_pretrained(
        model_name,
        trust_remote_code=True,
        padding_side="left",
        use_fast=True
    )
    tokenizer.pad_token = tokenizer.eos_token
    
    # 构建数据集
    train_dataset, data_collator = build_deepseek_trainset(
        source_data_path=source_data_path,
        tokenizer=tokenizer,
        chunk_size=block_size,
        times=times
    )
    print(f"✅ 成功加载训练样本数量: {len(train_dataset)}")
    print('Loading DeepSeek model...')
    # 全精度加载模型
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        trust_remote_code=True,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        #attn_implementation="flash_attention_2"
    )

    # 配置训练参数
    training_args = TrainingArguments(
        output_dir=output_dir,
        per_device_train_batch_size=per_device_train_batch_size,
        gradient_accumulation_steps=8,
        num_train_epochs=num_train_epochs,
        learning_rate=5e-5,
        weight_decay=0.01,
        bf16=True,
        logging_steps=10,
        optim="adamw_torch",
        save_strategy="no",
        save_steps=0,
        save_total_limit=0,
        max_grad_norm=0.5,
        warmup_ratio=0.1,
        lr_scheduler_type="cosine",
        report_to="none",
        gradient_checkpointing=True,
        remove_unused_columns=True,
        ddp_find_unused_parameters=True,
        dataloader_num_workers=4
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        data_collator=data_collator,
    )

    print('Start training...')
    tokenizer.save_pretrained(output_dir)
    trainer.train()
    
    # 保存完整模型
    model.save_pretrained(output_dir, safe_serialization=True)
    print(f'Model saved to {output_dir}')

if __name__ == '__main__':
    config = configparser.ConfigParser()
    config.read("/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/deepseek/config")
    
    parser = argparse.ArgumentParser()
    parser.add_argument("-mt", "--model_type", default="deepseek-tune",
                      choices=['reference', 'deepseek-tune'])
    args = parser.parse_args()

    train(
        source_data_path='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS_length/Datasets/deepseek_dataset_128/public',
        model_name="deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B",
        output_dir='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/deepseek/deepseek-1.5B/deepseek1.5b_pub',
        block_size=128,
        times=int(config.get("environment", "times")),
        per_device_train_batch_size=2,
        num_train_epochs=8
    )
