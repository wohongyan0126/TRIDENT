# finetune_neo.py

import torch
import os
import argparse
import configparser

from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    Trainer,
    TrainingArguments
)

from trainset_builder import build_GPT2_trainset


def train(source_data_path, model_name, output_dir, block_size, times, per_device_train_batch_size,
          num_train_epochs, save_steps):

    print("Loading tokenizer...")

    tokenizer = AutoTokenizer.from_pretrained(model_name)

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    print("Building dataset...")

    train_dataset, data_collator = build_GPT2_trainset(
        source_data_path=source_data_path,
        tokenizer=tokenizer,
        block_size=block_size,
        times=times
    )

    print(f"Dataset size: {len(train_dataset)}")

    print("Loading model:", model_name)

    model = AutoModelForCausalLM.from_pretrained(
        model_name
    )

    model.config.use_cache = False

    training_args = TrainingArguments(

        output_dir=output_dir,


        per_device_train_batch_size=per_device_train_batch_size,

        num_train_epochs=num_train_epochs,

        save_steps=save_steps,
        gradient_accumulation_steps = 8,
        logging_steps=10,

        dataloader_num_workers=4,

        gradient_checkpointing=True,

        fp16=True,

        learning_rate=5e-6,

        weight_decay=0.01,

        warmup_ratio=0.01,

        lr_scheduler_type="cosine",
        

        report_to="none"
    )

    print("Initializing trainer...")

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        data_collator=data_collator
    )

    print("Start training...")

    tokenizer.save_pretrained(output_dir)

    trainer.train()

    print("Saving model to:", output_dir)

    trainer.save_model(output_dir)

    tokenizer.save_pretrained(output_dir)


if __name__ == '__main__':

    config = configparser.ConfigParser()

    config.read("/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt-neo-1.3B/config")

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "-mt",
        "--model_type",
        default="baseline-tune",
        choices=['reference', 'baseline-tune']
    )

    args = parser.parse_args()

    train(

        source_data_path='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS_length/Datasets/dataset_1024/public',

        model_name='EleutherAI/gpt-neo-1.3B',

        output_dir='/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt-neo-1.3B/output_model_1024/gptneo_1.3B_public',

        block_size=int(config.get("environment", "block_size")),

        times=int(config.get("environment", "times")),


        per_device_train_batch_size=int(config.get("environment", "per_device_train_batch_size")),

        num_train_epochs=int(config.get("environment", "num_train_epochs")),

        save_steps=int(config.get("environment", "save_steps"))

    )