import os
import torch
import json
from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers import logging
from rouge_score import rouge_scorer
from bert_score import BERTScorer
from math import exp
from collections import Counter
from nltk.translate.bleu_score import sentence_bleu
from nltk.translate.meteor_score import meteor_score
from nltk.tokenize import word_tokenize
from utils import get_samples_list

logging.set_verbosity_error()

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

############################################################
# 初始化评估器
############################################################

rouge_scorer_instance = rouge_scorer.RougeScorer(
    ['rouge1', 'rouge2', 'rougeL'],
    use_stemmer=True
)

bert_scorer = BERTScorer(lang="en")

############################################################
# Metric Functions
############################################################

def calculate_rouge(candidate, reference):

    scores = rouge_scorer_instance.score(candidate, reference)

    return scores['rouge1'].fmeasure


def calculate_ttr(tokens):

    unique_tokens = set(tokens)

    return len(unique_tokens) / len(tokens) if len(tokens) > 0 else 0


def calculate_ngram_stats(tokens, n):

    ngrams = [
        tuple(tokens[i:i+n])
        for i in range(len(tokens)-n+1)
    ]

    total = len(ngrams)

    unique = len(set(ngrams))

    distinct = unique / total if total > 0 else 0

    return {
        f"distinct_{n}": distinct,
        f"unique_{n}": unique
    }


def calculate_bleu(candidate_tokens, reference_tokens):

    return sentence_bleu([reference_tokens], candidate_tokens)


def calculate_meteor(candidate, reference):

    candidate_tokens = word_tokenize(candidate)
    reference_tokens = word_tokenize(reference)

    return meteor_score([reference_tokens], candidate_tokens)


def calculate_bertscore(candidate, reference):

    P, R, F1 = bert_scorer.score([candidate], [reference])

    return F1.mean().item()


def calculate_perplexity(text, model, tokenizer):

    input_ids = tokenizer(
        text,
        return_tensors="pt"
    ).input_ids.to(device)

    with torch.no_grad():

        outputs = model(input_ids, labels=input_ids)

        loss = outputs.loss.item()

    return exp(loss)

############################################################
# Sampling
############################################################

def sampling_based_distribution(
        target_text,
        model,
        tokenizer,
        n_samples=1,
        prefix_ratio=0.1
):

    words = target_text.split()

    prefix_length = max(1, int(len(words) * prefix_ratio))

    x_prefix = " ".join(words[:prefix_length])

    x_ref = " ".join(words[prefix_length:])

    max_model_length = model.config.max_position_embeddings

    input_ids = tokenizer(
        x_prefix,
        return_tensors='pt'
    ).input_ids.to(device)

    target_gen_length = len(x_ref.split())

    max_gen_length = min(
        max_model_length - input_ids.shape[1],
        target_gen_length
    )

    results = []

    for _ in range(n_samples):

        with torch.no_grad():

            outputs = model.generate(
    input_ids,
    max_new_tokens=max_gen_length,
    do_sample=True,
    temperature=0.9,
    top_p=0.9,
    pad_token_id=tokenizer.eos_token_id
)

        generated_tokens = outputs[0][input_ids.shape[1]:]

        candidate = tokenizer.decode(
            generated_tokens,
            skip_special_tokens=True
        )

        candidate_words = candidate.split()

        ref_words = x_ref.split()

        ttr = calculate_ttr(candidate_words)

        distinct_1 = calculate_ngram_stats(candidate_words, 1)

        distinct_2 = calculate_ngram_stats(candidate_words, 2)

        bleu = calculate_bleu(candidate_words, ref_words)

        meteor = calculate_meteor(candidate, x_ref)

        rouge = calculate_rouge(candidate, x_ref)

        bert_score = calculate_bertscore(candidate, x_ref)

        input_text = x_prefix + " " + x_ref
        perplexity = calculate_perplexity(input_text, model, tokenizer)

        results.append({

            "rouge": rouge,

            "bert_score": bert_score,

            "perplexity": perplexity,

            "ttr": ttr,

            "bleu": bleu,

            "meteor": meteor,

            "distinct_1": distinct_1,

            "distinct_2": distinct_2

        })

    return results

############################################################
# 主流程
############################################################

def run_samia_and_compute_differences(tokenizer, models, n_samples=1):

    samples_dir_path = "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt-neo-1.3B/dataset_128/public"

    output_dir = "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt-neo-1.3B/output_128_result_pub"

    os.makedirs(output_dir, exist_ok=True)

    file_list = os.listdir(samples_dir_path)

    for file in file_list:

        data = get_samples_list(
            os.path.join(samples_dir_path, file)
        )

        book_results = {

            "book_name": file.split(".")[0],

            "samples": []

        }

        for i, sample in enumerate(data):

            baseline_scores = sampling_based_distribution(

                sample,

                models["public_model"],

                tokenizer,

                n_samples

            )

            baseline_tune_scores = sampling_based_distribution(

                sample,

                models["copyright_model"],

                tokenizer,

                n_samples

            )

            sample_result = {

                "sample_index": i+1,

                "baseline_scores": baseline_scores,

                "baseline_tune_scores": baseline_tune_scores

            }

            book_results["samples"].append(sample_result)

            sample_output_path = os.path.join(

                output_dir,

                f"{file.split('.')[0]}_sample_{i+1}_results.json"

            )

            with open(sample_output_path, "w", encoding="utf-8") as f:

                json.dump(sample_result, f, indent=4, ensure_ascii=False)

            print(f"Saved sample {i+1}")

        book_output_path = os.path.join(

            output_dir,

            f"{file.split('.')[0]}_results.json"

        )

        with open(book_output_path, "w", encoding="utf-8") as f:

            json.dump(book_results, f, indent=4, ensure_ascii=False)

        print(f"Saved book results {file}")


############################################################
# Main
############################################################

if __name__ == "__main__":

    model_dirs = {

        "public_model":
        "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt-neo-1.3B/output_model_128/gptneo_1.3B_pub",

        "copyright_model":
        "/3250811033/why/why/copyright_protection/data_copyright/DIGGER_OURS/Digger/gpt-neo-1.3B/output_model_128/gptneo_1.3B_copyright"

    }

    print("Loading models...")

    models = {

        key: AutoModelForCausalLM.from_pretrained(path).to(device)

        for key, path in model_dirs.items()

    }

    tokenizer = AutoTokenizer.from_pretrained(

        model_dirs["public_model"]

    )

    if tokenizer.pad_token is None:

        tokenizer.pad_token = tokenizer.eos_token

    print("Models loaded successfully")

    run_samia_and_compute_differences(

        tokenizer=tokenizer,

        models=models,

        n_samples=1

    )